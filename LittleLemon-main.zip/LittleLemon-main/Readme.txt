- API endpoints
api/menu
api/bookings
api/users --> For Registeration

- Admin
username : admin
password : admin@lemon753

- User
username : mario
password : mario@lemon753
token : 36d0e4e84075be7bc846b8110d78a3c72738fcf7